namespace BaldifyMod
{
    public static class MyPluginInfo
    {
        public const string PLUGIN_GUID = "com.yourname.baldifymod";
        public const string PLUGIN_NAME = "BaldifyMod";
        public const string PLUGIN_VERSION = "1.0.0";
    }
} 