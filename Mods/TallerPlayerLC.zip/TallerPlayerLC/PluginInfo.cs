namespace TallPlayerMod
{
    public static class PluginInfo
    {
        public const string PLUGIN_GUID = "com.yourusername.tallplayermod";
        public const string PLUGIN_NAME = "Tall Player Mod";
        public const string PLUGIN_VERSION = "1.0.0";
    }
} 